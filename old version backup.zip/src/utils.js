export const currencyFormatter = new Intl.NumberFormat("es-ES", {
  currency: "eur",
  style: "currency",
  minimumFractionDigits: 0,
});
//FIXME: TODO: recode this with i18n in mind

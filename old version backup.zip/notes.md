

<div>expenses - {budget?.name} </div>

budget?, the ? states that if we have a name we will display it; 

we're gonna have an empty body, which is fine; 

TODO: 





-responsive; 

-option to extract all data from localStorage to an external json file perhaps? 



DONE: 

-better files/folder structure

-dark-mode // done, revisit styling soon; 

-viewexpensesmodal: work on the ternary operator